<!-- proses_pendaftaran.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Hasil Pendaftaran Kursus</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <?php
        // Buatkan Array Assosiatif untuk Kursus beserta harga nya. Lihat modul
        // Sesuaikan dengan value yang ada di HTML
        $harga_kursus = [
            "Web Development" => 2000000,
            "Mobile Development" => 2500000,
            "Data Science" => 3000000,
            "UI/UX Design" => 1500000
        ];

        // Terima data dari form. Gunakan nama sebagai contoh. 
        // Ambil data lain nya (email, kursus_dipilih, dan metode_pembayaran)
        $nama = $_POST['nama'];
        $email = $_POST['email'];

        // Cek apakah pengguna memilih kursus atau tidak
        $kursus_dipilih = isset($_POST['kursus']) ? $_POST['kursus'] : [];

        // Cek apakah pengguna memilih metode pembayaran
        $metode_pembayaran = isset($_POST['pembayaran']) ? $_POST['pembayaran'] : "";

        // Hitung total biaya. Silahkan gunakan looping untuk menghitung
        $total_biaya = 0;
        foreach ($kursus_dipilih as $kursus) {
            $total_biaya += $harga_kursus[$kursus];
        }


        // Hitung diskon/tambahan biaya berdasarkan metode pembayaran
        // Jika dibayar full, maka mendapatkan diskon 10%
        // Jika dibayar cicilan, maka akan ada biaya tambahan 5%
        // Gunakan IF 
        $keterangan_biaya = "";
        if ($metode_pembayaran == "full") {
            $diskon = $total_biaya * 0.10;
            $biaya_akhir = $total_biaya - $diskon;
            $keterangan_biaya = "Diskon 10%: Rp " . number_format($diskon, 0, '.', ',');
        } elseif ($metode_pembayaran == "cicilan") {
            $tambahan = $total_biaya * 0.05;
            $biaya_akhir = $total_biaya + $tambahan;
            $keterangan_biaya = "Tambahan 5%: Rp " . number_format($tambahan, 0, '.', ',');
        } else {
            $biaya_akhir = $total_biaya;
        }

        // Tampilkan hasil
        // Gunakan echo
        echo "<h2>Hasil Pendaftaran</h2>";

        echo "<div class='hasil-section'>";
        echo "<h3>Data Pendaftar</h3>";

        //echo nama dan email
        echo "Nama: $nama<br>";
        echo "Email: $email<br>";
        echo "</div>";

        echo "<div class='hasil-section'>";
        echo "<h3>Kursus yang Dipilih</h3>";

        //echo kursus yang dipilih. Cek terlebih dahulu apakah kursus ada atau tidak dengan IF
        if (!empty($kursus_dipilih)) {
            foreach ($kursus_dipilih as $kursus) {
                echo "- $kursus (Rp " . number_format($harga_kursus[$kursus], 0, '.', ',') . ")<br>";
            }
            } else {
                echo "Tidak ada kursus yang dipilih.";
            }
        echo "</div>";

        echo "<div class='hasil-section'>";
        echo "<h3>Rincian Biaya</h3>";
        echo "<div class='rincian-biaya'>";
        //echo data sesuai dengan contoh soal 
        //Total harga, keterangan biaya (diskon atau cicilan), dan Total akhir setelah diskon atau cicilan.
        echo "Total harga kursus: Rp " . number_format($total_biaya, 0, '.', ',') . "<br>";
        echo $keterangan_biaya . "<br>";
        echo "Total yang harus dibayar: Rp " . number_format($biaya_akhir, 0, '.', ',') . "<br><br>";

        //Ada bagian tambahan jika pengguna memilih opsi cicilan
        //Disini harus menampilkan cicilan pengguna (dicicil selama 3x)
        if ($metode_pembayaran == 'cicilan') {
            echo "<div class='cicilan'>";
            echo "Rincian Cicilan (3x):<br>";
            //Berarti biaya akhir / 3. Kemudian looping sebanyak 3x untuk menampilkan Biaya cicilan.
            $cicilan = $biaya_akhir / 3;
            for ($i = 1; $i <= 3; $i++) {
                echo "Cicilan ke-$i: Rp " . number_format($cicilan, 0, '.', ',') . "<br>";
            }
            echo "</div>";
        }
        echo "</div>";
        echo "</div>";

        echo "<a href='form_pendaftaran.html' class='back-button'>Kembali ke Form</a>";
        ?>
    </div>
</body>

</html>